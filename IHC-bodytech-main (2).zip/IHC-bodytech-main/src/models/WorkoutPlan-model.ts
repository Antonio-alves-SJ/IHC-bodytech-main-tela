export interface WorkoutPlan {
  id: string;
  name: string;
  duration: number;
  calories: number;
  progress: number;
}
