export interface Stats {
    workouts: number;
    minutes: number;
    calories: number;
  }
  