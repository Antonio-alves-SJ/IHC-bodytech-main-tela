export type ExerciseCategory =
  | "Todos"
  | "Peito"
  | "Costas"
  | "Pernas"
  | "Braços"
  | "Ombros"
  | "Abdômen";
